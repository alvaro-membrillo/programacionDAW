public enum Tipo {
    BOSQUE, COSTA
}
