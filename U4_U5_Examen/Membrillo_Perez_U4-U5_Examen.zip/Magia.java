public interface Magia {

    boolean encantar(Personaje p);
    boolean desencantar(Personaje p);
}
