public interface Atacar {

    String atacarPersonaje(Personaje p);

}
