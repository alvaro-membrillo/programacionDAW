public abstract class Hombre extends Personaje {

    public Hombre(String nombre, int energia, int capAtaque, int capDefensa, boolean encantados) {
        super(nombre, energia, capAtaque, capDefensa, encantados);
    }
}
