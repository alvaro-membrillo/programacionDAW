package com.company;

public class Ej5 {
    public static void main(String[] args) {
        String[] v1 = new String[3];
        String[] v2 = new String[3];

        v1[0] = "a"; v1[1] = "b"; v1[2] = "c";
        v2[0] = "d"; v2[1] = "e"; v2[2] = "f";

        VectoresExamen.unir(v1, v2);
    }
}
