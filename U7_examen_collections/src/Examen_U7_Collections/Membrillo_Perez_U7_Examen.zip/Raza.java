package examenCollections;

public enum Raza {
    PASTOR_ALEMAN, LABRADOR, SAN_BERNARDO
}
